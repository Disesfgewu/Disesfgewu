print(1<2 or len(1))
