print(list(range(3)))

