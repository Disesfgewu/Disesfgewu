# 老師給的 test
print(1<2)
print(1==2)


# print(True)
# print(False)
# print(True and False)
# print(True or False)


# print(True == False)
# print(True != False)
# print(True <  False)
# print(True <= False)
# print(True >  False)
# print(True >= False)


# # 瞎生的 是這樣嗎(?

# # and 
# if True and False:
#     print("True and False is True")
# else:
#     print("True and False is False")  # Output: True and False is False

# # or
# if True or False:
#     print("True or False is True")  # Output: True or False is True
# else:
#     print("True or False is False")

# # not
# if not False:
#     print("not False is True")  # Output: not False is True
# else:
#     print("not False is False")

# # 另一個 not
# if not True:
#     print("not True is True")
# else:
#     print("not True is False")  # Output: not True is False



a = 5
b = 10

# ==
if a == b:
    print("a == b is True")
else:
    print("a == b is False")  # Output: a == b is False

# !=
if a != b:
    print("a != b is True")  # Output: a != b is True
else:
    print("a != b is False")

# >
if a > b:
    print("a > b is True")
else:
    print("a > b is False")  # Output: a > b is False

# <
if a < b:
    print("a < b is True")  # Output: a < b is True
else:
    print("a < b is False")

# >=
if a >= b:
    print("a >= b is True")
else:
    print("a >= b is False")  # Output: a >= b is False

# <=
if a <= b:
    print("a <= b is True")  # Output: a <= b is True
else:
    print("a <= b is False")