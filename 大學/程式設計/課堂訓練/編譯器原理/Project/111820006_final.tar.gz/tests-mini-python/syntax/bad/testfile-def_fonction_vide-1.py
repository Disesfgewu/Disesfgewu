def a () :
1


