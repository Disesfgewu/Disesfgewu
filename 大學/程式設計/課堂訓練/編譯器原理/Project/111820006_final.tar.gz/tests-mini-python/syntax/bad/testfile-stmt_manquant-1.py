def a () : 1


