def a (x x) : 1
1


