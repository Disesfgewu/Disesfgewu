def a () : 1
1
def a () : 1


