def f(x):
    return [ x ]


lst1 = [ 1, 2, 3, 4, 5, 6, 7 ]
lst2 = list(range(10))

lst3 = lst1 + lt2
lst4 = [ lst1, f(lst3) ]

