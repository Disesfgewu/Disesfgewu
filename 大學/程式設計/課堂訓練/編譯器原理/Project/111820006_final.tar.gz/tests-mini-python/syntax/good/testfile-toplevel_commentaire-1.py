x = 1

#commentaire

y = 2  #autre commentaire


print(x + y // 4 % f(10))


