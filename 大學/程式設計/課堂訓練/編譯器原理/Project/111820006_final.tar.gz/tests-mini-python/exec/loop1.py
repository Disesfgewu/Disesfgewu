def loop(x):
    print(x)
    if x < 3: loop(x+1)

loop(0)

