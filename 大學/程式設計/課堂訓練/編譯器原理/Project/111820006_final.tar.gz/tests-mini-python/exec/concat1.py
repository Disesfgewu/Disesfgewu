print("foo" + "bar")
