print(1==2)
