x = 42
print(x)
