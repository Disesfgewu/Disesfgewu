print(list())
