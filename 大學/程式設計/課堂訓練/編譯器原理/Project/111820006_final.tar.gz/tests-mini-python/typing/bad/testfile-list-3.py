
print(list(range()))
