
def f(x):
    if False:
       return x
    x = 1
    return x
print(f(0))
