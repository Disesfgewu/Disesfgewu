
def f():
    return x
x = 1
