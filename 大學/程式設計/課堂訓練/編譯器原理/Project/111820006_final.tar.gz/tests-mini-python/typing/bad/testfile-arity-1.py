def f(x):
    return f()
print(0)
