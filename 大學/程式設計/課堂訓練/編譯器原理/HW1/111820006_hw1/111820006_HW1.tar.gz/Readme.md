### Student Name : 陳羿錦
### Student ID : 111820006

for complie program and test
```bash=
    ./CompileAndTest.sh
```


reference:
    for Ex7 , I took reference from ChatGPT-3.5.