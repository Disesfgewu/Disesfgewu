echo "Ex7"
gcc -g ./matrix.s -o ./matrix && ./matrix